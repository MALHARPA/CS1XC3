/**
 * @file student.c
 * @author Malhar Patel
 * @brief The file contains function definiton related to student type
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * @brief Adds a grade to grade field of the specific entry
 * 
 * @param student Sudent receiving grade
 * @param grade grade which is added 
 * @return NULL
 */
void add_grade(Student* student, double grade)
{
  student->num_grades++;
  //Allocating memory space in grades forst first grade entry
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  else 
  {
    student->grades = 
    //reallocating the memory for the additional grade entry to be entered
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  //storing the grade in the allocated memory
  student->grades[student->num_grades - 1] = grade;
}

/**
 * @brief Calculating the average of the students grade
 * 
 * @param student student whose average is being calculated
 * @return Average of student's grade
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades);
}

/**
 * @brief Printing name,id,grade average of the specific student
 * 
 * @param student student whose info is being printed out
 * @return NULL
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
 * @brief A new student randomly generated from list of first and last name using rand()
 * 
 * @param grades The number of grades a student has
 * @return Student with randon info of his
 */
Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
  //Allocating memory space in students first grade entry
  Student *new_student = calloc(1, sizeof(Student));
  //Assigning random first name from 24 first names
  strcpy(new_student->first_name, first_names[rand() % 24]);
  //Assigning random last name from 24 first names
  strcpy(new_student->last_name, last_names[rand() % 24]);

  //Randomly generated 10 digits studentt id and typecasting to create an array of char i.e. string
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  //Adding up specific entry of grades to student grades using add_grade()
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}