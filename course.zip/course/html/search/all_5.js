var searchData=
[
  ['generate_5frandom_5fstudent_0',['generate_random_student',['../student_8c.html#ad0f523c2c17c9b40389cd8031052fc85',1,'generate_random_student(int grades):&#160;student.c'],['../student_8h.html#ad0f523c2c17c9b40389cd8031052fc85',1,'generate_random_student(int grades):&#160;student.c']]],
  ['grades_1',['grades',['../struct__student.html#ad0f75a9ff0f6104eb9e3bb3c4f7ad97b',1,'_student']]]
];
