/**
 * @file course.c
 * @author Malhar Patel 
 * @brief  The file here contains course-type related function definitions
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 
/**
 * @brief Adding/enrolling student to the member field of specific student.
 * 
 * @param course The course in which the student is enrolled to
 * @param student Student being enrolled
 * @return NULL value
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  //Memory space being allocated to "students" member field for the first enrolled student
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  //Reallocate the memory space in the students for new member to be added in course
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  //storing the student in the allocated space
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief Printing out code,name,total students of specified course.
 * 
 * @param course course of whose the information is being printed out.
 * @return NULL
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief Finding out student with the highest average in specific course.
 * 
 * @param course The course the fuciton looks into
 * @return Student with highest grade average in course 
 */
Student* top_student(Course* course)
{
  //Iterating through the course and finding out the highest average student
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief Students with average >= 50 being filtererd out here
 * 
 * @param course The course that is being loooked into
 * @param total_passing The number of studnets who pased the course
 * @return Student*
 */
Student *passing(Course* course, int *total_passing)
//this is a method of passing by the reference
{
  int count = 0;
  Student *passing = NULL;
  
  //Iterating through the loop to find out how many students pass the course
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  //Allocating the space for the students who pass the couse 
  passing = calloc(count, sizeof(Student));

  //Storing the student who pass in the course
  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  //Assignment of number of students who pass the course by pass-reference
  *total_passing = count;

  return passing;
}