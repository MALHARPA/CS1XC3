/**
 * @file main.c
 * @author Malhar Patel 
 * @brief This file contains all the libraries and demonstrates use of courses
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"
/**
 * @brief A course with random students enrolled in it is created and eventually printing 
 * information related to the course and the students .
 * 
 * @return The return value is 0 when the program executes successfully.
 */
int main()
{
  //Initializing random seed
  srand((unsigned) time(NULL));

  //This Creates course
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  //Random generated students are enrolled
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  //Printing the course information
  print_course(MATH101);

  //The sudent with the highest average is printed
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  //Prints out the students with having average >= 50 who pass the course 
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}