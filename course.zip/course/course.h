 /**
 * @file course.h
 * @author Malhar Patel
 * @brief This file has definition of function and couse type 
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "student.h"
#include <stdbool.h>
 
 /**
  * @brief Course Type stores the course info with 
  * code,name,students, total members
  * 
  */
typedef struct _course 
{
  char name[100];/**< The course name*/
  char code[10];/**< The course code*/
  Student *students;/**< The students enrolled in the course*/
  int total_students;/**< The number of students enroled in course */
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


